from flask import Flask, render_template, request

app =  Flask(__name__)

@app.route("/")
def home():    
    return render_template(
        "index.html",
        texto="Este é um parágrafo.",
        h2="Este é um subtítulo"
    )


# Rota principal
@app.route("/processar", methods=["POST"])

def processar():
    nome = request.form["nome"]    
    numero = request.form["numero"]
    mensagem = f"Olá {nome}, você digitou o número {numero}."
    return render_template("index.html", mensagem=mensagem)    

if __name__ == "__main__":
    app.run(debug=True)

