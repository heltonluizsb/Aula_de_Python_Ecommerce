from conexao import conectar

def insere():

    con = conectar()
    cur = con.cursor()

    nome = input("Nome do produto: ")
    preco = float(input("Preço: "))
    validade = input("Validade: ")
    tipo = input("Tipo: ")
    lote = int(input("Lote: "))
    ml = float(input("ml: "))
    piramide = input("Piramide: ")
    inspiracao = input("Insipração: ")
    marca = input("Marca: ")
    ocasiao = input("Ocasião: ")

    cur.execute("INSERT INTO produto VALUES(null, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", (nome, preco, validade, tipo, lote, ml, piramide, inspiracao, marca, ocasiao))
    con.commit()
    con.close()

def listar():

    con = conectar()
    cur = con.cursor()

    cur.execute("SELECT * FROM produto")
    for p in cur.fetchall():
        print(p)
        

def atualizar():
    con = conectar()
    cur = con.cursor()
    id_produto = int(input("ID do produto: "))
    preco = float(input("Novo preco: "))
    cur.execute("UPDATE produto SET preco = %s WHERE id = %s", (preco, id_produto))
    con.commit()
    con.close()

def excluir():
    con = conectar()
    cur = con.cursor()
    id_produto = int(input("ID do produto: "))
    cur.execute("DELETE FROM produto WHERE id = %s", (id_produto))
    con.commit()
    con.close() 

def menu():
    while True:
        print("\n1 - Inserir produto")
        print("2 - Listar Produto")
        print("3 - Atualizar produto")
        print("4 - Excluir produto")
        print("5 - Sair")

        opcao = input("Escolha: ")

        if opcao == "1":
            insere()
        elif opcao == "2":
            listar()
        elif opcao == "3":
            atualizar()
        elif opcao == "4":
            excluir()
        elif opcao == "5":
            break


menu()