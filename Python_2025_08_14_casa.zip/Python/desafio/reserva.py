import pymysql

escolha_espetaculo = 0
escolha_data = 0
escolha_cadeira = 0
cliente_id = 0
escolha_data_formatada = 0

def conectar():
    return pymysql.connect(
        host = 'localhost',
        user = 'root',
        password = '',
        database = 'reserva'
    )

def ListarReserva():

    con = conectar()
    cur = con.cursor(pymysql.cursors.DictCursor)
        
    print("Lista de reservas para este espetáculo: ")

    cur.execute("SELECT * FROM ingresso WHERE espetaculo_id = %s", (escolha_espetaculo))

    con.close()


def FazerReserva():
    escolha_existe = False

    while True:

        while escolha_existe == False:
            print("Escolha o Espetáculo:")

            con = conectar()
            cur = con.cursor(pymysql.cursors.DictCursor)

            cur.execute("SELECT * FROM espetaculo")

            espetaculo = cur.fetchall()

            for p in espetaculo:
                print(p)
            
            escolha_espetaculo = int(input("Escolha: "))
            
            for p in espetaculo:
                if p["ID"] == escolha_espetaculo:
                    escolha_existe = True

            if escolha_existe == False:
                print("Escolha incorreta. Escolha novamente.")

        ListarReserva()

        escolha_existe = False

        while escolha_existe == False:
            
            print("Escolha uma Data")
            print("1 - 2025-08-13")
            print("2 - 2025-08-14")
            print("3 - 2025-08-15")

            escolha_data = input("Escolha: ")
            
            if escolha_data == "1":
                escolha_data_formatada = '2025-08-13'
                escolha_existe = True
            elif escolha_data == "2":
                escolha_data_formatada = '2025-08-14'
                escolha_existe = True
            elif escolha_data == "3":
                escolha_data_formatada = '2025-08-15'
                escolha_existe = True
            else:
                print("Escolha incorreta. Escolha novamente.")

        escolha_existe = False

        while escolha_existe == False:
            
            print("Escolha uma Cadeira")
            print("cadeira 1")
            print("cadeira 2")
            print("cadeira 3")

            escolha_cadeira = input("Escolha: ")
            
            if escolha_cadeira == "1" or escolha_cadeira == "2" or escolha_cadeira == "3":
                escolha_existe = True
            else:
                print("Escolha incorreta. Escolha novamente.")


        con = conectar()
        cur = con.cursor()

        cur.execute("SELECT * FROM ingresso WHERE espetaculo_id = %s AND cadeira_id = %s AND data_hora = %s", (escolha_espetaculo, escolha_cadeira, escolha_data_formatada))

        ingresso_ocupado = False

        for p in cur.fetchall():
            ingresso_ocupado = True
        
        if ingresso_ocupado == True:
            print("Esta cadeira já está ocupada. Escolha outra.")
        else:
            cliente_id_existe = False
            
            while cliente_id_existe == False:
                cur.execute("SELECT * FROM cliente")
                clientes = cur.fetchall()
                for p in clientes:
                    print(p)
                cliente_id = input("Insira o ID do cliente: ")
                cur.execute("SELECT * FROM cliente WHERE id = %s", (cliente_id))
                cliente = cur.fetchall()
                if cliente:
                    cliente_id_existe = True
                else:
                    print("ID do cliente não encontrado. Tente novamente.")

            cur.execute("INSERT INTO ingresso VALUES(null, %s, %s, %s, %s)", (escolha_espetaculo, escolha_cadeira, escolha_data_formatada, cliente_id))
            con.commit()
            con.close()
            print("Reserva realizada com sucesso!")
            break
        
def CancelarReserva():
    print("Qual o Espetáculo que deseja cancelar a reserva? ")

    con = conectar()
    cur = con.cursor(pymysql.cursors.DictCursor)

    tem_espetaculo = False

    escolha_espetaculo_cancelar = 0

    while tem_espetaculo == False:

        cur.execute("SELECT * FROM espetaculo")
        espetaculo = cur.fetchall()

        for p in espetaculo:
            print(p)

        escolha_espetaculo_cancelar = int(input("Escolha: "))
                
        for p in espetaculo:
            if p["ID"] == escolha_espetaculo_cancelar:

                cur.execute("SELECT * FROM ingresso WHERE espetaculo_id = %s", (escolha_espetaculo_cancelar))

                espetaculo_vazio = True

                for p in cur.fetchall():
                    espetaculo_vazio = False
                
                if espetaculo_vazio == False:

                    tem_data = False

                    while tem_data == False:
                        
                        print("Escolha uma Data")
                        print("1 - 2025-08-13")
                        print("2 - 2025-08-14")
                        print("3 - 2025-08-15")

                        escolha_data = input("Escolha: ")
                        
                        if escolha_data == "1":
                            escolha_data_formatada = '2025-08-13'                            
                            tem_data = ChecarDataCancelamento(escolha_espetaculo_cancelar, escolha_data_formatada)
                        elif escolha_data == "2":
                            escolha_data_formatada = '2025-08-14'
                            tem_data = ChecarDataCancelamento(escolha_espetaculo_cancelar, escolha_data_formatada)
                        elif escolha_data == "3":
                            escolha_data_formatada = '2025-08-15'
                            tem_data = ChecarDataCancelamento(escolha_espetaculo_cancelar, escolha_data_formatada)
                        else:
                            print("Escolha incorreta. Escolha novamente.")

                    espetaculo_vazio = True
                    tem_espetaculo = True

                else:
                    print("Não existem cadeiras reservadas para esse espetaculo. Escolha outro.")


        if tem_espetaculo == False:
            print("Escolha incorreta. Escolha novamente.")


def ChecarDataCancelamento(escolha_espetaculo, escolha_data_formatada):

    con = conectar()
    cur = con.cursor(pymysql.cursors.DictCursor)

    cur.execute("SELECT * FROM ingresso WHERE espetaculo_id = %s AND data_hora = %s", (escolha_espetaculo, escolha_data_formatada))

    data_vazia = True                            
                            
    cadeiras = cur.fetchall()



    for p in cadeiras:
        data_vazia = False
    
    if data_vazia == False:

        cadeira_id_existe = False

        while cadeira_id_existe == False:

            print("Escolha uma cadeira para cancelamento: ")

            for p in cadeiras:
                print(f"Cadeira: {p["cadeira_id"]}")

            cadeira_id = input("Escolha: ")

            for p in cadeiras:
                if p["cadeira_id"] == cadeira_id:
                    cur.execute("DELETE FROM ingresso WHERE id = %s",(p["ID"]))
                    con.commit()
                    print("Cancelamento realizadao com sucesso!")
                    con.close()
                    cadeira_id_existe = True

            if cadeira_id_existe == False:
                print("Não existe essa cadeira. Escolha novamente.")
            

        return True
    else:
        print("Não existe cadeiras para essa data. Escolha uma nova")
        return False



    
        
def ListarReservaEspetaculo():
    print("Qual o Espetáculo que deseja Listar? ")

    con = conectar()
    cur = con.cursor(pymysql.cursors.DictCursor)

    tem_espetaculo = False
                    
    espetaculo_vazio = True

    escolha_espetaculo_listar = 0

    while tem_espetaculo == False and espetaculo_vazio == True:

        cur.execute("SELECT * FROM espetaculo")
        espetaculo = cur.fetchall()

        for p in espetaculo:
            print(p)

        escolha_espetaculo_listar = input("Escolha: ")

        cur.execute("SELECT * FROM ingresso WHERE espetaculo_id = %s", (escolha_espetaculo_listar))
        lista_espetaculo = cur.fetchall()

        for p in espetaculo:
            if p["ID"] == int(escolha_espetaculo_listar):
                tem_espetaculo = True
                
        if tem_espetaculo == False:
            print("Não existe esse espetáculo. Escolha novamente.")
        else:
                
            for p in lista_espetaculo:
                if p["espetaculo_id"] == escolha_espetaculo_listar:
                    espetaculo_vazio = False

            if espetaculo_vazio == False:
                ListaData(escolha_espetaculo_listar, "2025-08-13")
                ListaData(escolha_espetaculo_listar, "2025-08-14")
                ListaData(escolha_espetaculo_listar, "2025-08-15")

            else:
                tem_espetaculo = False
                print("Esse espetáculo está vazio. Escolha outro.")

def ListaData(escolha_espetaculo_listar, data_listar):

    print(f"{data_listar}: ")

    con = conectar()
    cur = con.cursor(pymysql.cursors.DictCursor)

    cur.execute("SELECT * FROM ingresso WHERE espetaculo_id = %s AND data_hora = %s", (escolha_espetaculo_listar, data_listar))

    listando_data = cur.fetchall()

    data_vazia = True

    for p in listando_data:
        data_vazia = False
    
    if data_vazia == False:

        for p in listando_data:
            print(f"Cadeira {p["cadeira_id"]}")

    else:
        print("Não existem cadeiras reservadas para essa data.")



def menu():
    while True:
        print("\n1 - Fazer Reserva")
        print("2 - Cancelar Reserva")
        print("3 - Listar Reserva do Espetáculo")
        print("4 - Sair")

        opcao = input("Escolha: ")

        if opcao == "1":
            FazerReserva()
        elif opcao == "2":
            CancelarReserva()
        elif opcao == "3":
            ListarReservaEspetaculo()
        elif opcao == "4":
            break


menu()