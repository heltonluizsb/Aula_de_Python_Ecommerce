import pymysql

def conectar():
    return pymysql.connect(host='localhost', user='root', password='', database='reserva')

def listar_espetaculos():
    con = conectar()
    with con.cursor(pymysql.cursors.DictCursor) as cur:
        cur.execute("SELECT * FROM espetaculo")
        esp = cur.fetchall()
    con.close()
    for e in esp: print(e)
    return esp

def listar_clientes():
    con = conectar()
    with con.cursor(pymysql.cursors.DictCursor) as cur:
        cur.execute("SELECT * FROM cliente")
        clientes = cur.fetchall()
    con.close()
    for c in clientes: print(c)
    return clientes

def listar_reservas(espetaculo_id, data=None):
    con = conectar()
    with con.cursor(pymysql.cursors.DictCursor) as cur:
        if data:
            cur.execute("SELECT * FROM ingresso WHERE espetaculo_id = %s AND data_hora = %s", (espetaculo_id, data))
        else:
            cur.execute("SELECT * FROM ingresso WHERE espetaculo_id = %s", (espetaculo_id,))
        reservas = cur.fetchall()
    con.close()
    return reservas

def escolher_opcao(msg, opcoes):
    while True:
        print(msg)
        for i, op in enumerate(opcoes, 1):
            print(f"{i} - {op}")
        escolha = input("Escolha: ")
        if escolha.isdigit() and 1 <= int(escolha) <= len(opcoes):
            return opcoes[int(escolha)-1]

def FazerReserva():
    esp = listar_espetaculos()
    esp_ids = [e["ID"] for e in esp]
    espetaculo_id = None
    while espetaculo_id not in esp_ids:
        espetaculo_id = int(input("Escolha o ID do espetáculo: "))

    datas = ["2025-08-13", "2025-08-14", "2025-08-15"]
    data_escolhida = escolher_opcao("Escolha a data:", datas)

    cadeiras = ["1", "2", "3"]
    cadeira_escolhida = escolher_opcao("Escolha a cadeira:", cadeiras)

    if listar_reservas(espetaculo_id, data_escolhida):
        if any(r["cadeira_id"] == cadeira_escolhida for r in listar_reservas(espetaculo_id, data_escolhida)):
            print("Cadeira ocupada!")
            return

    clientes = listar_clientes()
    cliente_ids = [str(c["id"]) for c in clientes]
    cliente_id = None
    while cliente_id not in cliente_ids:
        cliente_id = input("ID do cliente: ")

    con = conectar()
    with con.cursor() as cur:
        cur.execute("INSERT INTO ingresso VALUES (NULL, %s, %s, %s, %s)",
                    (espetaculo_id, cadeira_escolhida, data_escolhida, cliente_id))
        con.commit()
    con.close()
    print("Reserva realizada com sucesso!")

def CancelarReserva():
    esp = listar_espetaculos()
    espetaculo_id = None
    while espetaculo_id not in [e["ID"] for e in esp]:
        espetaculo_id = int(input("Escolha ID do espetáculo: "))

    datas = ["2025-08-13", "2025-08-14", "2025-08-15"]
    data_escolhida = escolher_opcao("Escolha a data:", datas)

    reservas = listar_reservas(espetaculo_id, data_escolhida)
    if not reservas:
        print("Nenhuma reserva nessa data.")
        return

    for r in reservas: print(f"Cadeira: {r['cadeira_id']}")
    cadeira = input("Escolha a cadeira para cancelar: ")

    con = conectar()
    with con.cursor() as cur:
        cur.execute("DELETE FROM ingresso WHERE espetaculo_id = %s AND data_hora = %s AND cadeira_id = %s",
                    (espetaculo_id, data_escolhida, cadeira))
        con.commit()
    con.close()
    print("Reserva cancelada com sucesso!")

def ListarReservaEspetaculo():
    espetaculo_id = None
    esp = listar_espetaculos()
    while espetaculo_id not in [e["ID"] for e in esp]:
        espetaculo_id = int(input("Escolha ID do espetáculo: "))

    datas = ["2025-08-13", "2025-08-14", "2025-08-15"]
    for data in datas:
        reservas = listar_reservas(espetaculo_id, data)
        print(f"{data}:")
        if reservas:
            for r in reservas: print(f"Cadeira {r['cadeira_id']}")
        else:
            print("Nenhuma cadeira reservada.")

def menu():
    opcoes = {
        "1": FazerReserva,
        "2": CancelarReserva,
        "3": ListarReservaEspetaculo,
        "4": exit
    }
    while True:
        print("\n1 - Fazer Reserva\n2 - Cancelar Reserva\n3 - Listar Reserva\n4 - Sair")
        escolha = input("Escolha: ")
        if escolha in opcoes:
            opcoes[escolha]()

if __name__ == "__main__":
    menu()