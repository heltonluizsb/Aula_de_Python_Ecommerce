from flask import Flask, render_template, request, redirect, url_for, session

import mysql.connector
from mysql.connector import IntegrityError

app =  Flask(__name__)
app.secret_key = 'troque_sua_chave_secreta'

def conectar():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="2025_08_19"
    )

def home():
    return redirect(url_for('login'))

@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    mensagem = None
    if request.method == "POST":
        nome = request.form["nome", ""].strip()
        email = request.form["email", ""].strip()
        senha = request.form["senha", ""].strip()

    if not nome or not email or not senha:
        mensagem = "Preencha todos os campos."
    else:
        try:
            con = conectar()
            cursor = con.cursor()
            cursor.execute("INSERT INTO clientes (nome, email, senha) VALUES (%s, %s, %s)",
                           (nome, email, senha)
                )
            con.commit()
            con.close()

            return redirect(url_for('login'))
        except IntegrityError:
            mensagem = "Email já cadastrado. Tente outro."
        except Exception as e:
            mensagem = f"Erro ao cadastrar: {str(e)}"
        
    return render_template("cadastro.html", mensagem=mensagem)

@app.route("/login", methods=["GET", "POST"])
def login():
    mensagem = None
    if request.method == "POST":
        email = request.form["email", ""].strip()
        senha = request.form["senha", ""].strip()
        if not email or not senha:
            mensagem = "informe email e senha."
        else:
            con = conectar()
            cursor = con.cursor()
            cursor.execute(
                "SELECT * FROM clientes WHERE email = %s AND senha = %s",
                (email, senha)
            )
            usuario = cursor.fetchone()
            con.close()
            if usuario:
                session['usuario_id'] = usuario[0]
                session['usuario_nome'] = usuario[1]
                session['usuario_email'] = usuario[2]
                return redirect(url_for('menu'))
            else:
                mensagem = "Login inválido. Verifique email/senha."
    return render_template("login.html", mensagem=mensagem)

def requere_login():
    return 'usuario_id' in session

@app.route("/menu")
def menu():
    if not requere_login():
        return redirect(url_for('login'))
    return render_template("menu.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for('login'))

def calc():
    if not requere_login():
        return redirect(url_for('login'))
    
    resultado = None
    erro = None

    if request.method == "POST":
        try:
            n1 = int(request.form.get("n1", "0"))
            n2 = int(request.form.get("n2", "0"))
            op = request.form.get("op", "soma")

            if op == "soma":
                resultado = n1 + n2
            elif op == "sub":
                resultado = n1 - n2
            elif op == "mult":
                resultado = n1 * n2
            elif op == "div":
                if n2 != 0:
                    resultado = n1 / n2
                else:
                    erro = "Divisão por zero não é permitida."
            else:
                erro = "Operação inválida."
        except ValueError:
            erro = "Por favor, insira números válidos."
        
    return render_template("calc.html", resultado=resultado, erro=erro)

def idade():
    if not requere_login():
        return redirect(url_for('login'))
    
    mensagem = None
    erro = None

    if request.method == "POST":
        try:
            idade_valor = int(request.form.get("idade", "0"))
            mensagem = "Maior de idade" if idade_valor >= 18 else "Menor de idade"
        except ValueError:
            erro = "Digite um número válido."
        
    return render_template("idade.html", mensagem=mensagem, erro=erro)

@app.route("/lista")
def lista():
    if not requere_login():
        return redirect(url_for('login'))
    
    numeros = list(range(1, 11))
    return render_template("lista.html", numeros=numeros)