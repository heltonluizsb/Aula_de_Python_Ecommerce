from flask import Flask, render_template, request, redirect, url_for, session
from markupsafe import Markup

import os
import mysql.connector
from mysql.connector import IntegrityError

def adiciona_css_thumbnail(temp_url):

    if temp_url is None or temp_url == '':
        temp_url = 'home'    

    css_path = os.path.join('static', 'css', f'{temp_url}.css')

    if os.path.exists(css_path):
        href = url_for('static', filename=f'css/{temp_url}.css')
        return Markup(f'<link href="{href}" type="text/css" rel="stylesheet" />')
    return f'<p>não encontrou nada em {css_path}</p>'

app = Flask(__name__)
app.jinja_env.globals.update(adiciona_css_thumbnail=adiciona_css_thumbnail)

@app.route('/', defaults={'url_path': ''})
@app.route('/<path:url_path>')
def home(url_path=None):
    url = url_path.split('/')[0] if url_path else ''
    return render_template('index.html', page='home', url=url)


@app.route('/cadastro')
def cadastro(url_path=None):
    url = url_path.split('/')[0] if url_path else ''
    return render_template('index.html', page='cadastro', url=url)

@app.route('/login')
def login(url_path=None):
    url = url_path.split('/')[0] if url_path else ''
    return render_template('index.html', page='login', url=url)

if __name__ == "__main__":
    app.run(debug=True)